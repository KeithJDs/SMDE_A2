if (!require("FactoMineR")) install.packages
if (!require("car")) install.packages("car")
if (!require("RcmdrMisc")) install.packages("RcmdrMisc")
library("FactoMineR")
library("car")
library("RcmdrMisc")

YatesData <- read.table("YatesOutputMale.csv",
                              header = FALSE, sep = ",", na.strings = "NA",
                              dec = ".", strip.white = TRUE)

OriginalData <- read.table("OriginalDataMale.csv",
                            header = FALSE, sep = ",", na.strings = "NA",
                            dec = ".", strip.white = TRUE)



Simulated = data.frame(x1 = YatesData, x2 = "v1")

Original = data.frame(x1 = OriginalData, x2 = "v2")

data = mergeRows(Simulated, Original, common.only = FALSE)

AnovaModel.1 <- aov(V1 ~ x2, data = data)
summary(AnovaModel.1)
Boxplot(V1 ~ x2, data = data, id.method = "y")
