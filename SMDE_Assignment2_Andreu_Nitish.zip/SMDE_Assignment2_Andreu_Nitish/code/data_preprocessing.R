library("lubridate")


# Get the dataset
dataset <- read.csv(file = '../data/marathon_results_2017.csv')

# Filter by column
keeps <- c("M.F", "Age", "Official.Time", "X5K", "X10K", "X15K", "X20K", "X25K", "X30K", "X35K", "X40K")
dataset = dataset[keeps]

# Format time  
times <- c("Official.Time", "X5K", "X10K", "X15K", "X20K", "X25K", "X30K", "X35K", "X40K")
dataset[times] <- lapply(dataset[times], function(x) hour(hms(x))*60 + minute(hms(x)))
dataset$Pace <- dataset$Official.Time/42.195

# Drop na's
na.omit(dataset)

# Sector times
dataset$Sector_5 <- dataset$X5K
dataset$Sector_5_10 <- dataset$X10K - dataset$X5K
dataset$Sector_10_15 <- dataset$X15K - dataset$X10K
dataset$Sector_15_20 <- dataset$X20K - dataset$X15K
dataset$Sector_20_25 <- dataset$X25K - dataset$X20K
dataset$Sector_25_30 <- dataset$X30K - dataset$X25K
dataset$Sector_30_35 <- dataset$X35K - dataset$X30K
dataset$Sector_35_40 <- dataset$X40K - dataset$X35K
dataset$Sector_40_end <- dataset$Official.Time - dataset$X40K

# Subsets for Females and Males
dataset_male <- subset(dataset,  M.F == "M" &  Age >= 20 &  Age <= 30, )
dataset_female <- subset(dataset,  M.F == "F" &  Age >= 20 &  Age <= 30, )

# Linear Models
models <- c(Sector_5 ~ Pace,
            Sector_5_10 ~ Pace,
            Sector_10_15 ~ Pace,
            Sector_15_20 ~ Pace,
            Sector_20_25 ~ Pace,
            Sector_25_30 ~ Pace,
            Sector_30_35 ~ Pace,
            Sector_35_40 ~ Pace,
            Sector_40_end ~ Pace)

lapply(models, function(x) summary(lm(x, data=dataset_male)))
lapply(models, function(x) summary(lm(x, data=dataset_female)))

# Testing Regression Assumptions
## 1. Normality of the Error Term
lapply(models, function(x) shapiro.test(residuals((lm(x, data=dataset_male)))))
lapply(models, function(x) shapiro.test(residuals((lm(x, data=dataset_female)))))
# The error term does not follow a Normal distribution. (p<0.05)

# 2. Homogenity of Variance
# Breusch Pagan Test
library(lmtest)
lapply(models, function(x) bptest(lm(x, data=dataset_male)))
lapply(models, function(x) bptest(lm(x, data=dataset_female)))
# H0 is accepted (p>0.05).
# The homogenity of variances is provided.

# 3. The independence of errors
lapply(models, function(x) dwtest(lm(x, data=dataset_male), alternative = "two.sided"))
# There is not an autocorrelaiton in the data set (p>0.05).
# The errors/observations are independent.

# Pace distribution
h = hist(dataset$Pace)
h$density = h$counts/sum(h$counts)*100
plot(h,freq=FALSE)
print(h)



